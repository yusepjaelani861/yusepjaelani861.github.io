Repo by : https://github.com/MichaelBelgium/VPS-Monitor

Demo: https://monitor-vps.herokuapp.com/

-Add meta viewport so it will responsive on mobile device<br>
-Add function bytes To Size (kb, mb, gb, tb)<br>
-Automaticaly select default interface (wlan,eth, ...)<br>
-Add condition on formatNumber() in case variable number is undefined<br>
